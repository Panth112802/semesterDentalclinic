package T3.DataLayer.DAO;

public class TestH {

	public static void main(String[] args) {
	
		
		PatientHandler ph = new PatientHandler();
		
	}

}
