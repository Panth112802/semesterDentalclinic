package T2.sharedPackage.Schedule;

import java.util.Date;
import java.util.Timer;

public interface ISchedule {

	public Timer getAllTime();
	
	public Date getAllDate();
}
