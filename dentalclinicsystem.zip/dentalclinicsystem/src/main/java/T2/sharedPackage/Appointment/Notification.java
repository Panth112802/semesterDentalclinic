package T2.sharedPackage.Appointment;

import java.io.Serializable;
import java.text.MessageFormat;

public class Notification implements Serializable {

	private MessageFormat message;
}
