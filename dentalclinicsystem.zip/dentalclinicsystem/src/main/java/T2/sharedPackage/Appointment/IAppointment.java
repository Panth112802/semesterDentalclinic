package T2.sharedPackage.Appointment;


import java.util.Timer;
import java.util.Date;

public interface IAppointment  {

	public Timer getAllTime();
	public Date getAllDate();
}
