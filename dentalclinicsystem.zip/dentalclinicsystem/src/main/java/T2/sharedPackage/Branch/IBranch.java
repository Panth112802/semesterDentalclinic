package T2.sharedPackage.Branch;

public interface IBranch {

	public Branch getAllBranch();
	
}
