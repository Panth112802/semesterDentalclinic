package T2.sharedPackage.Address;

import java.io.Serializable;

public interface IAddress {

	public Address getAddress();
	
}
