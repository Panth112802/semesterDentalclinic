package T2.Logic.PatientController;

public class TestClass {

	public static void main(String[] args) {
		
		
		PatientControllerImp  pacimp = new PatientControllerImp();
		
	}

}
