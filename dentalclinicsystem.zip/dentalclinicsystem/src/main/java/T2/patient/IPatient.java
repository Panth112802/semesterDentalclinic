package T2.patient;

public interface IPatient {

   public String getFirstname();

	public String getLastName();
	
	public String getCprNo();
	
	public String Email();
	
	public String getPassword();
	
	
}
