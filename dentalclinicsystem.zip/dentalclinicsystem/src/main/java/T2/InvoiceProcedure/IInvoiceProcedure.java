package T2.InvoiceProcedure;

public interface IInvoiceProcedure {

	public Procedure getTotalPrice();
	
	//public Procedure getProcedureType();
}
