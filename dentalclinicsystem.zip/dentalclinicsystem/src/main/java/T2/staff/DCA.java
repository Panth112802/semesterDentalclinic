package T2.staff;

import java.io.Serializable;

public class DCA extends Staff implements Serializable{

	
	public DCA(String userName, String password) {
		
		super(userName, password);


	}

	
}
