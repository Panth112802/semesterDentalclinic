package T2.staff;

public interface IStaff {

	public String gerUserName();
	
	public String getPassword();
	
	public String Dentist();
	
	public Dentist getAllDentist();
}
