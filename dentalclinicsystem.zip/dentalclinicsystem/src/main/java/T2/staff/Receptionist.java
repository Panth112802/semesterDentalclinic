package T2.staff;

import java.io.Serializable;

public class Receptionist extends Staff implements Serializable {

	
	public Receptionist(String userName, String password) {
		super(userName, password);
		
	}

}
